---
name: Feature request
about: Suggest an idea for this library
title: ''
labels: feature request
assignees: ''

---

**Is it within the scope of this library?**
Consider and describe why the feature would be beneficial in this library, and not implemented as a separate project using this as a dependency.

**Describe the solution you'd like**
A clear and concise description of what you want to happen.
